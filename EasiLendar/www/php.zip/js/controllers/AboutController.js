/**
 * starter: Can Duy Cat
 * owner: Can Duy Cat
 * last update: 09/03/2015
 * type: about controller (version)
 */

angular.module('MainApp.controllers.about', [])

.controller("AboutController", function($scope) {
    $scope.ver = "1.1.6.[113]"
})
