/**
 * starter: Can Duy Cat
 * owner: Nguyen Manh Duy
 * last update: 24/02/2015
 * type: home controller
 */

angular.module('MainApp.controllers.home', [])

.controller("HomeController", function($scope) {

})
