/**
 * starter: Can Duy Cat
 * owner: Can Duy Cat
 * last update: 09/03/2015
 * type: paticular con troller
 */

angular.module('MainApp.controllers.setting', [])

.controller('SettingController', function($scope) {
})
