/**
 * starter: Can Duy Cat
 * owner: Nguyen Thi Luong
 * last update: 24/02/2015
 * type: paticular controller
 */

angular.module('MainApp.controllers.profile', [])

.controller("ProfileController", function($scope, $ionicPopup) {

})
